package visualizacao;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;

import modelo.Carro;
import modelo.Fabrica;

public class EntradaSaida {
	
	

	public static int solicitaOpcao() {
		
		
		
		String[] opcoes = {"Fabricar Carros", "Vender um carro", "Ver informa��es do carro","Sair do programa"};
		JComboBox<String> menu = new JComboBox<String>(opcoes);
		JOptionPane.showConfirmDialog(null, menu, "Selecione a op��o desejada", JOptionPane.OK_CANCEL_OPTION);
	
	return menu.getSelectedIndex();
	
		
		
	}

	public static void exibeMensagemEncerra() {
		JOptionPane.showMessageDialog(null, "O programa ser� encerrado!");
		
	}	
	

	public static void fabricarCarros() {
		
		Fabrica fabrica = new Fabrica();
		Carro carro = new Carro();
		
		
		fabrica.fabricarCarro(carro);
		
	}

	public static void venderCarros() {
		Fabrica fabrica = new Fabrica();
		
		Carro carro = new Carro();
		String cor="";
		int qtdCor=0;
		String[] coresCarros = new String[qtdCor];
		fabrica.venderCarro(carro, cor, coresCarros);
	}

	public static void informacoesCarros() {
		
		Fabrica fabrica = new Fabrica();
		
		Carro carro = new Carro();
		String info="";
		fabrica.imprimeInfoCarros(carro, info);
		
	}
	
	public static String solicitaCor() {
		return JOptionPane.showInputDialog("Informe a cor do carro");
		
		
	}
	
	public static String solicitaModelo() {
		return JOptionPane.showInputDialog("Informe o modelo do carro");		
		
	}
	
	public static int solicitaAno() {
		return Integer.parseInt(JOptionPane.showInputDialog("Informe o ano do carro"));		
		
	}

	

	

}
