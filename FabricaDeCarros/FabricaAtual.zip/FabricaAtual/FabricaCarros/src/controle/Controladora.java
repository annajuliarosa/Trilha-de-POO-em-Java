package controle;

import java.util.ArrayList;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;

import modelo.Carro;
import modelo.Fabrica;
import visualizacao.EntradaSaida;

public class Controladora {
 //realiza a inicializa��o do objeto
	private Fabrica fabrica = null;
	private Carro carro = null;

	public void exibirMenu() {

		int opcao;

		this.fabrica = new Fabrica();

		do {

			int qtdCarros = 0;

			opcao = EntradaSaida.solicitaOpcao();

			if (this.carro == null && opcao > 0) {

				do {
					JOptionPane.showMessageDialog(null, "N�o h� carros dispon�veis");
					opcao = EntradaSaida.solicitaOpcao();

				} while (this.carro == null && opcao > 0);

			}

			switch (opcao) {

			case 0:

				qtdCarros = Integer.parseInt(
						JOptionPane.showInputDialog("Informe a quantidade de carros que gostaria de fabricar"));

				while (qtdCarros < 1) {
					qtdCarros = Integer.parseInt(JOptionPane.showInputDialog(
							"Valor inv�lido! Informe a quantidade de carros que gostaria de fabricar"));
				}

				for (int i = 0; i < qtdCarros; i++) {

					this.carro = new Carro();
					fabrica.fabricarCarro(carro);

				}

				break;

			case 1:

				// pega a lista de carros da fabrica
				ArrayList<Carro> listaDeCarros = fabrica.getListaDeCarros();
				// boleano que valida a lista atraves do metodo isEmpty
				boolean validaLista = listaDeCarros.isEmpty();
				// se a lista possui carros, realiza a venda
				if (validaLista == false) {
					// passa a lista como parametro para o metodo da entrada e saida solicitando o
					// carro a vender
					int carroEscolhido = EntradaSaida.escolherCarroVender(listaDeCarros);
					// passa o carro escolhido como parametro para o metodo de vender carro na
					// fabrica

					if (carroEscolhido != -1) {
						fabrica.venderCarro(carroEscolhido);
						
					} else {
						// se m�todo retornou -1, usuario clicou cancelar, venda nao � realizada;
						JOptionPane.showMessageDialog(null, "Voc� clicou cancelar");
					}
				} else {
					JOptionPane.showMessageDialog(null, "N�o h� carros a venda.");
				}
				
				break;

			case 2:
				String info = "";

				if (fabrica.getListaDeCarros().size() == 0) {
					JOptionPane.showMessageDialog(null, "N�o h� carros");
				} else {
					for (Carro carro : fabrica.getListaDeCarros()) {

						info += "Modelo: " + carro.getModelo() + " | Cor: " + carro.getCor() + " | Ano: "
								+ carro.getAno() + "\n";

					}

					fabrica.imprimeInfoCarros(carro, info);
				}
				break;

			case 3:
				EntradaSaida.exibeMensagemEncerra();
				break;

			}

		} while (opcao != 3);

	}

}
