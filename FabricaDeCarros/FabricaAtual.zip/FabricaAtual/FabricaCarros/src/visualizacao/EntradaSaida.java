package visualizacao;

import java.util.ArrayList;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;

import modelo.Carro;
import modelo.Fabrica;

public class EntradaSaida {

	public static int solicitaOpcao() {

		String[] opcoes = { "Fabricar Carros", "Vender um carro", "Ver informa��es do carro", "Sair do programa" };
		JComboBox<String> menu = new JComboBox<String>(opcoes);
		JOptionPane.showConfirmDialog(null, menu, "Selecione a op��o desejada", JOptionPane.OK_CANCEL_OPTION);

		return menu.getSelectedIndex();

	}

	public static void exibeMensagemEncerra() {
		JOptionPane.showMessageDialog(null, "O programa ser� encerrado!");

	}

	public static String solicitaCor() {
		return JOptionPane.showInputDialog("Informe a cor do carro");

	}

	public static String solicitaModelo() {
		return JOptionPane.showInputDialog("Informe o modelo do carro");

	}

	public static int solicitaAno() {
		int ano = Integer.parseInt(JOptionPane.showInputDialog("Informe o ano do carro"));
		while (ano < 1) {

		}

		return ano;

	}

	public static int escolherCarroVender(ArrayList<Carro> listaDeCarros) {
		// oferta as opcoes de carro para vender, recebendo como parametro a lista de
		// carros
		int qtDeCarros = listaDeCarros.size();
		// constr�i o vetor para o JComboBox a partir da listaDeCarros
		String[] descricaoCarros = new String[qtDeCarros];
		String[] corCarros = new String[qtDeCarros];
		String[] opcaoVenda = new String[qtDeCarros];

		for (int i = 0; i < qtDeCarros; i++) {
			descricaoCarros[i] = listaDeCarros.get(i).getModelo();
			corCarros[i] = listaDeCarros.get(i).getCor();
			// cria string para cor + modelo na hora da venda
			opcaoVenda[i] = descricaoCarros[i] + " - " + corCarros[i];
		}

		// cria JComboBox com o vetor descricaoCarros
		JComboBox<String> escolherCarroVender = new JComboBox<String>(opcaoVenda);
		// se usuario clicar cancelar, armazena na variavel confirmar "2";
		int confirmar = JOptionPane.showConfirmDialog(null, escolherCarroVender, "Qual carro deseja vender?",
				JOptionPane.OK_CANCEL_OPTION);
		// se ele clica ok, armazena 0 na variavel confirmar
		if (confirmar == 0) {
			int carroEscolhido = escolherCarroVender.getSelectedIndex();
			return carroEscolhido;
// se nao, retorna -1
		} else {
			return -1;
		}
	}
}
