package modelo;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import visualizacao.EntradaSaida;


public class Fabrica {
	
	Carro carro = new Carro();
	
	private ArrayList<Carro> listaDeCarros = new ArrayList<Carro>();
	
	public ArrayList<Carro> getListaDeCarros() {
		return listaDeCarros;
	}
	
	public void setListaDeCarros(ArrayList<Carro> listaDeCarros) {
		this.listaDeCarros=listaDeCarros;
	}
	
	public void venderCarro() {
				
	
			Carro carro = new Carro();
		String cor1= JOptionPane.showInputDialog("Informe a cor do carro que gostaria de vender: " + carro.getCor());
		String modelo=  JOptionPane.showInputDialog("Informe o modelo do carro que gostaria de vender");
		
		
		
		
	
			
			System.out.print(carro.getCor());
			
			if (cor1==carro.getCor() && modelo==carro.getModelo()) {
				
				listaDeCarros.remove(carro);
				
				
		}		
		
	
	  }
		
	
		
	public void fabricarCarro(Carro carro) {	
			carro.setCor(EntradaSaida.solicitaCor());
			carro.setModelo(EntradaSaida.solicitaModelo());
			carro.setAno(EntradaSaida.solicitaAno());			
			listaDeCarros.add(carro);
			
			
		 				
			
		}		
		
		
		
		
	
	
	public void imprimeInfoCarros(Carro carro) {
		
		String mostrarInfo="";
		
		mostrarInfo=carro.getCor() + " \n"+  carro.getAno() + " \n"+  carro.getModelo();
		
		System.out.print(mostrarInfo);
			
		
		}
		
	
	
	

}
