package controle;

import javax.swing.JOptionPane;

import modelo.Carro;
import modelo.Fabrica;
import visualizacao.EntradaSaida;

public class Controladora {
	
	Fabrica fabrica = null;
	Carro carro= null;

	public void exibirMenu() {
		
		int opcao;	
		
		
		
		do {
		
		opcao=EntradaSaida.solicitaOpcao();
		
		switch(opcao) {
		
		case 0:
			
			this.fabrica = new Fabrica();
			this.carro = new Carro();
						
			int qtdCarros=Integer.parseInt(JOptionPane.showInputDialog("Informe a quantidade de carros que gostaria de fabricar"));
			
			for (int i=0; i<qtdCarros; i++) {
				
				fabrica.fabricarCarro(carro);
			}
								
			 
		
			
		break;
		
		case 1:
			
			for (Carro carro1 : fabrica.getListaDeCarros()) {
				
				
			}
		 EntradaSaida.venderCarros();  	
						
		break;
		
		case 2:
			
			
			
			for (Carro carro: fabrica.getListaDeCarros()) {
				
				fabrica.imprimeInfoCarros(carro);
				
				
			}
		break;
	
		case 3:			
			EntradaSaida.exibeMensagemEncerra();			
		break;
			
		
		}
		
		}while(opcao!=3);
		
		
	}

}
