package Controle;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;

import Modelo.Conta;
import Modelo.Movimentacao;
import Visualizacao.EntradaSaida;

public class Controladora {

	private Conta conta = null;
	
	private Movimentacao movimentacao = null;

	public void exibirMenu() {
		
		int opcao=0;	
		
		this.conta= new Conta();
		this.movimentacao = new Movimentacao();
		do {
		
			
			
			opcao=EntradaSaida.solicitaOpcao();
			
			
			switch(opcao) {
			
			case 0:
				double valorDeposito=0;
				
				conta.setTitularDaConta(EntradaSaida.solicitarTitularDaConta());
				conta.setTipo(EntradaSaida.solicitaTipoDeConta());				
				
		        valorDeposito= EntradaSaida.solicitarInformacoesDeposito(valorDeposito);	
				
				conta.depositar(valorDeposito);
				//chamar construtor da movimentacao para setar dentro do objeto tipo da conta, valor e data
				
				/*movimentacao.setTipo();
				
				movimentacao
				set 
				
				
				conta.efetuarSaqueDep ()
				chamar m�todo que adiciona na lista.
											
				*/
				
			break;
			
			case 1:
				
				
			break;
				
			case 2:
				EntradaSaida.exibirSaldo(movimentacao);
				

				
			break;
			
			case 3:
				
			break;
			
			case 4:
				
			break;
			
			case 5:
				
			break;
			
			case 6:
				
			break;
			
			case 7:
				
			break;
			}
		
		
		
		
		}while(opcao!=7);

		
		
	}

}
