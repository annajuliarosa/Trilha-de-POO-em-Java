package Modelo;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import Visualizacao.EntradaSaida;

public class Conta {

	private String titularDaConta;
	private int tipo;
	private double saldo;
	private static ArrayList<Movimentacao> listaDeMovimentacao= new ArrayList<Movimentacao>();
	
	
	public String getTitularDaConta() {
		return titularDaConta;
	}
	
	public void setTitularDaConta(String titularDaConta) {
		this.titularDaConta=titularDaConta;
	}
	
	public int getTipo() {
		return tipo;
	}
	
	public void setTipo(int tipo) {
		this.tipo=tipo;
	}
	
	public double getSaldo() {
		return saldo;
	}
	
	public void setSaldo(double saldo) {
		this.saldo=saldo;
	}
	
	public ArrayList<Movimentacao> getListaDeMovimentacao() {
		return listaDeMovimentacao;
	}
	
	public void setListaDeMovimentacao(ArrayList<Movimentacao> listaDeMovimentacao) {
		this.listaDeMovimentacao=listaDeMovimentacao;
	}
	
	public void depositar(double valorDepositado) {
		
		saldo+=valorDepositado;
		
	}
	
	
	//fazer metodo que adc na lista.
	
	public void sacar() {
		
	}
	
	public void gerarSaldo(Movimentacao movimentacao) {
		
		
	
		
	//	for (Movimentacao movimentacao1 : conta.getListaDeMovimentacao()) {
		
			JOptionPane.showMessageDialog(null, getSaldo());
	//	}
		
		
		
			
		
	
	
	}
}
	
	
	

