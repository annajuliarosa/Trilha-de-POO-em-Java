package Visualizacao;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;

import Modelo.Conta;
import Modelo.Movimentacao;

public class EntradaSaida {

	public static int solicitaOpcao() {

		String[] opcoes = { "Solicitar Informa��es Deposito", "Solicitar Informa��es Saque", "Exibir Saldo",
				"Exibir dados da Conta" + "Exibir Extrato Completo", "Exibir Extrato Depositos",
				"Exibit Extrato de Saques" };
		JComboBox<String> menu = new JComboBox<String>(opcoes);
		JOptionPane.showConfirmDialog(null, menu, "Selecione a op��o desejada", JOptionPane.OK_CANCEL_OPTION);

		return menu.getSelectedIndex();

	}

	public static String solicitarTitularDaConta() {
		String titularConta = "";

		return titularConta = JOptionPane.showInputDialog("Informe o titular da conta: ");
	}

	public static int solicitaTipoDeConta() {
		int tipo = 0;

		return tipo = Integer
				.parseInt(JOptionPane.showInputDialog("Informe o tipo de conta 1 - para poupan�a 2 - para corrente"));
	}

	public static double solicitarInformacoesDeposito(double valorDeposito) {

		valorDeposito = Double.parseDouble(JOptionPane.showInputDialog("Informe o valor do dep�sito: "));

		return valorDeposito;

	}

	public static void solicitarInformacoesSaque() {

	}

	public static void exibirSaldo(Movimentacao movimentacao) {
		Conta conta = new Conta();

		conta.gerarSaldo(movimentacao);
	}

	public void exibirDadosDaConta() {

	}

	public void exibirExtratoCompleto() {

	}

	public void ExtratoDeDepositos() {

	}

	public void exibirExtratoDeSaques() {

	}

}
