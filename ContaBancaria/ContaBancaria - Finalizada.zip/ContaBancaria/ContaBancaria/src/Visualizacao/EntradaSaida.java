package Visualizacao;

import java.sql.Date;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;

import Modelo.Conta;
import Modelo.Movimentacao;

public class EntradaSaida {

	public static int solicitaOpcao() {

		String[] opcoes = { "Solicitar Informa��es Deposito", "Solicitar Informa��es Saque", "Exibir Saldo",
				"Exibir dados da Conta", "Exibir Extrato Completo", "Exibir Extrato Depositos",
				"Exibir Extrato de Saques", "Sair" };
		JComboBox<String> menu = new JComboBox<String>(opcoes);
		JOptionPane.showConfirmDialog(null, menu, "Selecione a op��o desejada", JOptionPane.OK_CANCEL_OPTION);

		return menu.getSelectedIndex();

	}

	public static String solicitarTitularDaConta() {
		String titularConta = "";

		return titularConta = JOptionPane.showInputDialog("Informe o titular da conta: ");
	}

	public static int solicitaTipoDeConta() {
		int tipo = 0;

		tipo = Integer
				.parseInt(JOptionPane.showInputDialog("Informe o tipo de conta 1 - para poupan�a 2 - para corrente"));
		while (tipo < 0 || tipo > 2) {
			tipo = Integer.parseInt(
					JOptionPane.showInputDialog("Valor inv�lido, digite novamente! \nInforme o tipo de conta 1 - para poupan�a 2 - para corrente"));
		}
		
		return tipo;
	}

	public static double solicitarInformacoesDeposito(double valorDeposito) {

		valorDeposito = Double.parseDouble(JOptionPane.showInputDialog("Informe o valor do dep�sito: "));

		return valorDeposito;

	}

	public static int tipoDeMovimentacao(int ordem) {

		if (ordem == 0) {
			return 0;
		} else {
			return 1;

		}
	}

	public static double solicitarInformacoesSaque(double valorSaque) {

		valorSaque = Double.parseDouble(JOptionPane.showInputDialog("Informe o valor do saque: "));
		return valorSaque;

	}

	public static void exibirSaldo(String info) {

		JOptionPane.showMessageDialog(null, info);

	}

	public static void exibirDadosDaConta(String info) {

		JOptionPane.showMessageDialog(null, info);

	}

	public static void exibirExtratoCompleto(String info) {
		JOptionPane.showMessageDialog(null, info);

	}

	public static void exibirExtratoDeDepositos(String info) {

		JOptionPane.showMessageDialog(null, info);
	}

	public static void exibirExtratoDeSaques(String info) {

		JOptionPane.showMessageDialog(null, info);

	}

	public static void mensagemSaida() {

		JOptionPane.showMessageDialog(null, "Programa ser� encerrado!");

	}

}
