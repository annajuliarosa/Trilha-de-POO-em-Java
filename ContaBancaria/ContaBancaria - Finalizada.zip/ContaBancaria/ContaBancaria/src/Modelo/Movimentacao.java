package Modelo;

import java.sql.Date;
import java.util.Calendar;

public class Movimentacao {
	
	private int  tipo;
	private double valor;
	private Calendar data = Calendar.getInstance();
	
	
	
	public int getTipo() {
		return tipo;
	}
	
	public void setTipo(int tipo) {
		this.tipo=tipo;
	}
	
	public double getValor() {
		return valor;
	}
	
	public void setValor(double valor) {
		this.valor=valor;
	}
	
	public Calendar getData() {
		return data;
	}
	
	public void setData(Calendar data) {
		this.data=data;
	}

}
