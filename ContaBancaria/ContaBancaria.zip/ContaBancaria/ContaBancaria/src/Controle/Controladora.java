package Controle;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;

public class Controladora {

	public int exibirMenu() {
		
		String[] opcoes = {"Solicitar Informa��es Deposito", "Solicitar Informa��es Saque", "Exibir Saldo","Exibir dados da Conta"
				+ "Exibir Extrato Completo"};
		JComboBox<String> menu = new JComboBox<String>(opcoes);
		JOptionPane.showConfirmDialog(null, menu, "Selecione a op��o desejada", JOptionPane.OK_CANCEL_OPTION);
	
	    return menu.getSelectedIndex();
		
		


		
		
	}

}
