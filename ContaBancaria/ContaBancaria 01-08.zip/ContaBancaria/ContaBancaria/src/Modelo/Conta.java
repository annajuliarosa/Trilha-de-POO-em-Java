package Modelo;

import java.util.ArrayList;


import Visualizacao.EntradaSaida;

public class Conta {

	private String titularDaConta;
	private int tipo;
	private double saldo;
	private static ArrayList<Movimentacao> listaDeMovimentacao= new ArrayList<Movimentacao>();
	
	
	public String getTitularDaConta() {
		return titularDaConta;
	}
	
	public void setTitularDaConta(String titularDaConta) {
		this.titularDaConta=titularDaConta;
	}
	
	public int getTipo() {
		return tipo;
	}
	
	public void setTipo(int tipo) {
		this.tipo=tipo;
	}
	
	public double getSaldo() {
		return saldo;
	}
	
	public void setSaldo(double saldo) {
		this.saldo=saldo;
	}
	
	public ArrayList<Movimentacao> getListaDeMovimentacao() {
		return listaDeMovimentacao;
	}
	
	public void setListaDeMovimentacao(ArrayList<Movimentacao> listaDeMovimentacao) {
		this.listaDeMovimentacao=listaDeMovimentacao;
	}
	
	public void depositar(double valorDepositado) {
		
		saldo+=valorDepositado;
		
		
		System.out.print(saldo);
	}
	
	
	public void adicionaLista(Movimentacao movimentacao){
		
		listaDeMovimentacao.add(movimentacao);
	
		
	}
			
	public void sacar(double valorSaque) {
		
	saldo-=valorSaque;	
	
		
	}
	
	
	
	public void gerarSaldo(String info) {
		
				
		for (Movimentacao movimentacao : getListaDeMovimentacao()) {

			info= "saldo: " +getSaldo();

		}
		
		EntradaSaida.exibirSaldo(info);
		
		}
	
		
 	public void gerarDadosDaConta(String info) {
 		for (Movimentacao movimentacao : getListaDeMovimentacao()) {
 			
 			info+= "Nome titular da conta: " + getTitularDaConta() + "\nTipo da Conta: " + getTipo() + "\nSaldo " + getSaldo();
 			
 			
 		}
 		
 		EntradaSaida.exibirDadosDaConta(info);
 		
 	}
 	
 	public void gerarExtrato(String info) {
 		
 		for (Movimentacao movimentacao : getListaDeMovimentacao()) {
 			info+= "Tipo de Movimentacao: " + movimentacao.getTipo() + "\nvalor: " + movimentacao.getValor() + "\nData " + movimentacao.getData();
 			
 		}
 		
 		EntradaSaida.exibirExtratoCompleto(info);
 		
 	}
 	
 	public void gerarExtratoDepositos(String info) {
 		
 		for (Movimentacao movimentacao : getListaDeMovimentacao()) {
 			info+= "Tipo de Movimentacao: " + movimentacao.getTipo() + "\nvalor: " + movimentacao.getValor() + "\nData " + movimentacao.getData();
 			
 		}
 		
 		EntradaSaida.exibirExtratoDeDepositos(info);
 		
 		
 	}
 	
 	
 	


		
		
			
		
	
	
	
}
	
	
	

