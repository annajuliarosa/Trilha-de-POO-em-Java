package Controle;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;

import Modelo.Conta;
import Modelo.Movimentacao;
import Visualizacao.EntradaSaida;

public class Controladora {

	private Conta conta = null;
	
	private Movimentacao movimentacao = null;

	public void exibirMenu() {
		
		int opcao=0;	
		
		this.conta= new Conta();	
		
		
		conta.setTitularDaConta(EntradaSaida.solicitarTitularDaConta());
		conta.setTipo(EntradaSaida.solicitaTipoDeConta());
				
		do {
			
			opcao=EntradaSaida.solicitaOpcao();		
			
			String info="";
			
			switch(opcao) {
			
			case 0:
				double valorDeposito=0;
				
		        valorDeposito= EntradaSaida.solicitarInformacoesDeposito(valorDeposito);	
				
				conta.depositar(valorDeposito);
				
				this.movimentacao = new Movimentacao();
				
				if(opcao==0) {
					movimentacao.setTipo(EntradaSaida.tipoDeMovimentacao(0));		
				}
				
				movimentacao.setData(EntradaSaida.solicitaData());					
				movimentacao.setValor(valorDeposito);								
				conta.adicionaLista(movimentacao);
				
				
				
				
			break;
			
			case 1:
				
				double valorSaque=0;			
				
					
				valorSaque=EntradaSaida.solicitarInformacoesSaque(valorSaque);
				
				conta.sacar(valorSaque);	
				
				this.movimentacao = new Movimentacao();
				if(opcao==1) {
					movimentacao.setTipo(EntradaSaida.tipoDeMovimentacao(1));	
					
				}				
			
				movimentacao.setData(EntradaSaida.solicitaData());			
				movimentacao.setValor(valorSaque);
				
				conta.adicionaLista(movimentacao);
				
				
			break;
				
			case 2:
								
				conta.gerarSaldo(info);
				
			break;
			
			case 3:
				conta.gerarDadosDaConta(info);
				
			break;
			
			case 4:				
				conta.gerarExtrato(info);			
				
				
			break;
			
			case 5:
				
				if (opcao==0) {
					System.out.print("Cheguei");
					conta.gerarExtratoDepositos(info);
					
					
					
					
				}
			//	gerarExtratoDepositos()
				

				
			break;
			
			case 6:
				
			break;
			
			case 7:
				
			break;
			}
		
		
		
		
		}while(opcao!=7);

		
		
	}

	
}
