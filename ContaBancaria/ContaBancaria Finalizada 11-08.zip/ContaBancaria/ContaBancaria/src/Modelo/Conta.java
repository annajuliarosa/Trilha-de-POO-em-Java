package Modelo;

import java.text.DecimalFormat;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import Visualizacao.EntradaSaida;

public class Conta {

	private String titularDaConta;
	private int tipo;
	private double saldo;
	private static ArrayList<Movimentacao> listaDeMovimentacao = new ArrayList<Movimentacao>();
	
	DecimalFormat df = new DecimalFormat("00.00");

	public String getTitularDaConta() {
		return titularDaConta;
	}

	public void setTitularDaConta(String titularDaConta) {
		this.titularDaConta = titularDaConta;
	}

	public int getTipo() {
		return tipo;
	}

	public void setTipo(int tipo) {
		this.tipo = tipo;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public ArrayList<Movimentacao> getListaDeMovimentacao() {
		return listaDeMovimentacao;
	}

	public void setListaDeMovimentacao(ArrayList<Movimentacao> listaDeMovimentacao) {
		this.listaDeMovimentacao = listaDeMovimentacao;
	}

	public void depositar(double valorDepositado) {
		
		

		saldo += valorDepositado;
		
	}

	public void adicionaLista(Movimentacao movimentacao) {

		listaDeMovimentacao.add(movimentacao);

	}

	public void sacar(double valorSaque) {
		
		if (saldo-valorSaque < (-1000)) {
			
			JOptionPane.showMessageDialog(null, "Limite da conta ultrapassado!");
		}else {
			
		saldo -= valorSaque;
		
		}
	}

	public void gerarSaldo(String info) {

		for (Movimentacao movimentacao : getListaDeMovimentacao()) {

			info = "Saldo da conta: R$" +  df.format(getSaldo());

		}

		EntradaSaida.exibirSaldo(info);

	}

	public void gerarDadosDaConta(String info) {
		for (Movimentacao movimentacao : getListaDeMovimentacao()) {

			info = "Nome titular da conta: " + getTitularDaConta() + "\nTipo da Conta:\n1- Poupan�a -  2 - Corrente: " + getTipo() + "\nSaldo "
					+ getSaldo();

		}

		EntradaSaida.exibirDadosDaConta(info);

	}

	public void gerarExtrato(String info) {
		String tipoTransacao = "";
		for (Movimentacao movimentacao : getListaDeMovimentacao()) {

			if (movimentacao.getTipo() == 0) {
				tipoTransacao = "Deposito";
			} else {
				tipoTransacao = "Saque";
			}

			info += "Tipo de Movimentacao: " + tipoTransacao + "\nValor da Movimenta��o: R$" + df.format(movimentacao.getValor()) + "\nData da Movimenta��o: "
					+ movimentacao.getData().getTime()+ "\n--------------------------------------------------------------------\n";

		}

		EntradaSaida.exibirExtratoCompleto(info);

	}

	public void gerarExtratoDepositos(String info) {
		
		String tipoTransacao = "";

		for (Movimentacao movimentacao : getListaDeMovimentacao()) {
			if (movimentacao.getTipo() == 0) {
				tipoTransacao = "Deposito";
				info += "Tipo de Movimentacao: " + tipoTransacao + "\nValor da Movimenta��o: R$" + df.format(movimentacao.getValor()) + "\nData da Movimenta��o: "
						+ movimentacao.getData().getTime()+ "\n--------------------------------------------------------------------\n";

			}
		}

		EntradaSaida.exibirExtratoDeDepositos(info);

	}

	public void gerarExtratoSaques(String info) {

		String tipoTransacao = "";

		for (Movimentacao movimentacao : getListaDeMovimentacao()) {
			if (movimentacao.getTipo() == 1) {
				tipoTransacao = "Saque";
				info += "Tipo de Movimentacao: " + tipoTransacao + "\nValor da Movimenta��o: R$" + df.format(movimentacao.getValor()) + "\nData da Movimenta��o: "
						+ movimentacao.getData().getTime()+ "\n--------------------------------------------------------------------\n";
															
			}				
			
		}
		
		EntradaSaida.exibirExtratoDeSaques(info);
		
		

	}

}
