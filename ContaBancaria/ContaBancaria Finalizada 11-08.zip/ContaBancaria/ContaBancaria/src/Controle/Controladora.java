package Controle;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;

import Modelo.Conta;
import Modelo.Movimentacao;
import Visualizacao.EntradaSaida;

public class Controladora {

	private Conta conta = null;

	private Movimentacao movimentacao = null;

	public void exibirMenu() {

		boolean check = false;

		int opcao = 0;

		this.conta = new Conta();

		conta.setTitularDaConta(EntradaSaida.solicitarTitularDaConta());
		conta.setTipo(EntradaSaida.solicitaTipoDeConta());

		do {

			opcao = EntradaSaida.solicitaOpcao();

			if (opcao == 6 && check == false) {
				JOptionPane.showMessageDialog(null, "N�o h� extrato de saques!");
			} else {

				if (this.movimentacao == null && opcao > 0 && opcao<7) {

					JOptionPane.showMessageDialog(null, "N�o h� dados inseridos na conta!!!");

				} else {

					String info = "";

					switch (opcao) {

					case 0:
						double valorDeposito = 0;

						valorDeposito = EntradaSaida.solicitarInformacoesDeposito(valorDeposito);

						conta.depositar(valorDeposito);

						this.movimentacao = new Movimentacao();

						if (opcao == 0) {
							movimentacao.setTipo(EntradaSaida.tipoDeMovimentacao(0));

						}

						movimentacao.setValor(valorDeposito);
						conta.adicionaLista(movimentacao);

						break;

					case 1:

						double valorSaque = 0;

						valorSaque = EntradaSaida.solicitarInformacoesSaque(valorSaque);
						while (valorSaque < 0 || valorSaque > 1000)
							valorSaque = EntradaSaida.solicitarInformacoesSaque(valorSaque);

						conta.sacar(valorSaque);

						this.movimentacao = new Movimentacao();
						if (opcao == 1) {
							movimentacao.setTipo(EntradaSaida.tipoDeMovimentacao(1));
							check = true;

						}

						movimentacao.setValor(valorSaque);
						conta.adicionaLista(movimentacao);

						break;

					case 2:

						conta.gerarSaldo(info);

						break;

					case 3:
						conta.gerarDadosDaConta(info);

						break;

					case 4:
						conta.gerarExtrato(info);

						break;

					case 5:
						conta.gerarExtratoDepositos(info);

						break;

					case 6:
						conta.gerarExtratoSaques(info);

						break;

					case 7:
						EntradaSaida.mensagemSaida();
						System.exit(0);

						break;
					}

				}
			}
		} while (opcao != 7);

	}

}
