
public class Operacao {

}
