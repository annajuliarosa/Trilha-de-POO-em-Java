package modelo;

public class Subtracao extends Operacoes {
	
	

public double calcula() {
		
		double sub= num1-num2;
		return sub;
	
	}
}
