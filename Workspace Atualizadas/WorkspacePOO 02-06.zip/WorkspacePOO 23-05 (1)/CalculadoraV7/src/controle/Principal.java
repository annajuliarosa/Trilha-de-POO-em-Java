package controle;
import javax.swing.JOptionPane;

import modelo.Divisao;
import modelo.Multiplicacao;
import modelo.Operacoes;
import modelo.Soma;
import modelo.*;
import modelo.Subtracao;
import visualizacao.EntradaSaida;

public class Principal {	

	public static void main(String[] args) {
		
		Controladora controladora = new Controladora();
		controladora.exibeMenu();
		
		
	}
	
	



	
}



