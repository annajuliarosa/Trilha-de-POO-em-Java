
public class Soma extends Operacoes {
	

public double calcula() {
		
		double soma = num1+num2;
		return soma;
	}
}
