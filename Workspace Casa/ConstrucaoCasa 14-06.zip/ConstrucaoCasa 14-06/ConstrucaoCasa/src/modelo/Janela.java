package modelo;

public class Janela extends Aberturas{}
