package Modelo;

import java.sql.Date;
import java.text.DecimalFormat;
import java.util.ArrayList;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;

import Visualiza��o.EntradaSaida;

public class Loja {

	private ArrayList<Produtos> listaDeProdutos = new ArrayList<Produtos>();
	private ArrayList<Cupom> listaDeCupom = new ArrayList<Cupom>();

	public ArrayList<Produtos> getListaDeProdutos() {
		return listaDeProdutos;
	}

	public void setListaDeProdutos(ArrayList<Produtos> listaDeProdutos) {
		this.listaDeCupom = listaDeCupom;
	}

	public ArrayList<Cupom> getListaDeCupom() {
		return listaDeCupom;
	}

	public void setListaDeCupom(ArrayList<Cupom> listaDeCupom) {
		this.listaDeCupom = listaDeCupom;
	}

	public void cadastrarProdutos(Produtos produtos) {

		listaDeProdutos.add(produtos);

	}

	public void exibirProdutos(String info) {

		DecimalFormat df = new DecimalFormat("00.00");

		for (Produtos produto : getListaDeProdutos()) {
			info += "C�digo do Produto: " + produto.getCodigoProduto() + "\nDescricao do produto: "
					+ produto.getDescricao() + "\nPre�o do produto: R$" + df.format(produto.getPreco()) + "\n ";

		}

		EntradaSaida.exibirInformacoes(info);
	}

	public void entradaEstoque(int codigoProduto, int quantidade) {

		for (Produtos produtos : getListaDeProdutos()) {
			if (produtos.getCodigoProduto() == codigoProduto) {
				produtos.setQuantidade(produtos.getQuantidade() + quantidade);

			}
		}

	}

	public boolean validacaoCodigo(int codigoProduto) {

		boolean check = false;

		for (Produtos produto : getListaDeProdutos()) {
			if (codigoProduto == produto.getCodigoProduto()) {
				check = true;

			}
		}

		return check;
	}

	public void exibirEstoque(String info) {

		for (Produtos produtos : getListaDeProdutos()) {
			info += "C�digo do Produto: " + produtos.getCodigoProduto() + "\nQuantidade de Produtos: "
					+ produtos.getQuantidade() + "\n ";
			;

		}

		EntradaSaida.exibirInformacoes(info);

	}

	public void venderProdutos(int codigoProduto, Cupom cupom) {

		double totalVenda = 0;

		cupom.setQuantidade(EntradaSaida.qtdVenda());
		for (Produtos produtos : getListaDeProdutos()) {

			if (produtos.getCodigoProduto() == codigoProduto) {

				if (cupom.getQuantidade() > produtos.getQuantidade()) {
					JOptionPane.showMessageDialog(null, "N�o h� produtos suficiente em estoque!!!");
				} else {

					produtos.setQuantidade(produtos.getQuantidade() - cupom.getQuantidade());
					cupom.getdataVenda().getTime();
					cupom.setDescricao(produtos.getDescricao());
					totalVenda = cupom.getQuantidade() * produtos.getPreco();
					cupom.setTotal(totalVenda);

					listaDeCupom.add(cupom);

				}
			}
		}
	}

	public void exibirCupom(String info) {

		DecimalFormat df = new DecimalFormat("00.00");

		for (Cupom cupom : getListaDeCupom()) {
			info += "Data da Venda: " + cupom.getdataVenda().getTime() + "\nDescricao do Produtos: "
					+ cupom.getDescricao() + "\nQuantidade vendida: " + cupom.getQuantidade() + "\nValor total: R$"
					+ df.format(cupom.getTotal()) + "\n ";

		}

		EntradaSaida.exibirInformacoes(info);

	}

	public void valorTotalCupons(String info) {

		double total = 0;

		DecimalFormat df = new DecimalFormat("00.00");

		for (Cupom cupom : getListaDeCupom()) {

			total += cupom.getTotal();

			info = "Total das vendas: R$" + df.format(total);
		}

		EntradaSaida.exibirInformacoes(info);

	}

}
