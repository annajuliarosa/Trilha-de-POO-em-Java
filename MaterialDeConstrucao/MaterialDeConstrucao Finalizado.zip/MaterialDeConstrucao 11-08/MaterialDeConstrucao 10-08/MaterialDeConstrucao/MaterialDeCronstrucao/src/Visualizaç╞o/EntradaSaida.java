package Visualiza��o;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;

import Modelo.Loja;
import Modelo.Produtos;

public class EntradaSaida {

	public static int solicitaOpcao() {

		String[] opcoes = { "Cadastrar Produtos", "Exibir Produtos", "Entrada em Estoque", "Vender Produto",
				"Exibir Produtos em estoque", "Exibir Cupons", "Exibir total de vendas", "Sair" };
		JComboBox<String> menu = new JComboBox<String>(opcoes);
		JOptionPane.showConfirmDialog(null, menu, "Selecione a op��o desejada", JOptionPane.OK_CANCEL_OPTION);

		return menu.getSelectedIndex();

	}

	public static String solicitaDescricao() {

		String descricao = JOptionPane.showInputDialog("Informe a descricao do produto: ");

		return descricao;

	}

	public static double solicitaPreco() {

		double preco = Double.parseDouble(JOptionPane.showInputDialog("Informe o valor do produto: "));
		while (preco<0) {
			preco = Double.parseDouble(JOptionPane.showInputDialog("Valor inv�lido, digite novamente! Informe o valor do produto: "));
		}

		return preco;

	}

	public static int solicitaCodigoProduto(int codigoProduto, String valores) {

		codigoProduto = Integer.parseInt(JOptionPane.showInputDialog("Informe o c�digo do produto: " + valores));

		return codigoProduto;

	}

	public static int solicitaCodigoProdutoComprar(int codigoProduto, String valoresComprar) {

		codigoProduto = Integer.parseInt(
				JOptionPane.showInputDialog("Informe o c�digo do produto que gostaria de comprar: " + valoresComprar));

		return codigoProduto;

	}

	public static int qtdEstoque(int quantidade) {

		quantidade = Integer
				.parseInt(JOptionPane.showInputDialog("Informe a quantidade do produto que gostaria de inserir: "));
		while (quantidade<1) {
			quantidade = Integer
					.parseInt(JOptionPane.showInputDialog("Valor inv�lido, digite novamente! Informe a quantidade do produto que gostaria de inserir: "));
		}
		
			
		
		return quantidade;

	}

	public static int qtdVenda() {
		

		int quantidade2=0;
		
		quantidade2 = Integer
				.parseInt(JOptionPane.showInputDialog("Informe a quantidade do produto que gostaria de comprar: "));
		
		while (quantidade2<1) {
			quantidade2 = Integer
					.parseInt(JOptionPane.showInputDialog("Valor inv�lido, digite novamente! Informe a quantidade do produto que gostaria de inserir: "));
		}
	

		return quantidade2;

	}

	public static void exibirInformacoes(String info) {

		JOptionPane.showMessageDialog(null, info);
	}

}
