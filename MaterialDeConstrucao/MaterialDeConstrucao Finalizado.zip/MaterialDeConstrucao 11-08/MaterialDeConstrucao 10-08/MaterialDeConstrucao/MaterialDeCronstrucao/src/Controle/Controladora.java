package Controle;

import java.text.DecimalFormat;

import javax.swing.JOptionPane;

import Modelo.Cupom;
import Modelo.Loja;
import Modelo.Produtos;
import Visualiza��o.EntradaSaida;

public class Controladora {

	Loja loja = null;

	Produtos produtos = null;

	Cupom cupom = null;

	public void exibirMenu() {
		int opcao = 0;

		this.loja = new Loja();

		int codigo = 0;

		do {

			opcao = EntradaSaida.solicitaOpcao();
			int codigoProduto = 0;
			String info = "";
			if (opcao == 0) {
				codigo++;
			}

			if (this.produtos == null && opcao > 0 && opcao < 7) {

				JOptionPane.showMessageDialog(null, "N�o h� produtos cadastrados");

			} else {

				switch (opcao) {

				case 0:

					this.produtos = new Produtos();

					produtos.setCodigoProduto(codigo);
					produtos.setDescricao(EntradaSaida.solicitaDescricao());
					produtos.setPreco(EntradaSaida.solicitaPreco());

					loja.cadastrarProdutos(produtos);

					break;

				case 1:

					loja.exibirProdutos(info);

					break;

				case 2:

					this.produtos = new Produtos();

					String valores = "";
					for (Produtos produto : loja.getListaDeProdutos()) {

						valores += "\nC�digo do produto: " + produto.getCodigoProduto() + "\nDescricao Produtos: "
								+ produto.getDescricao() + "\n";
					}

					int quantidade = 0;

					codigoProduto = EntradaSaida.solicitaCodigoProduto(codigoProduto, valores);

					if (loja.validacaoCodigo(codigoProduto) == true) {
						quantidade = EntradaSaida.qtdEstoque(quantidade);

						loja.entradaEstoque(codigoProduto, quantidade);

					} else {
						JOptionPane.showMessageDialog(null, "C�digo inv�lido");

					}

					break;

				case 3:
					
					DecimalFormat df = new DecimalFormat("00.00");
					String valoresComprar = "";
					for (Produtos produto : loja.getListaDeProdutos()) {


							valoresComprar += "\nC�digo do produto: " + produto.getCodigoProduto()
									+ "\nDescricao Produtos: " + produto.getDescricao() + "\nQuantidade: "
									+ produto.getQuantidade() + "\nValor do Produto: R$" + df.format(produto.getPreco())
									+ "\n";

					}
					
					codigoProduto = EntradaSaida.solicitaCodigoProdutoComprar(codigoProduto, valoresComprar);
					
							if (loja.validacaoCodigo(codigoProduto) == true) {

								this.cupom = new Cupom();
								
								loja.venderProdutos(codigoProduto, cupom);

							} else {
								JOptionPane.showMessageDialog(null, "C�digo inv�lido!");

							}
						
					break;

				case 4:

					loja.exibirEstoque(info);

					break;

				case 5:

					if (this.cupom == null) {
						JOptionPane.showMessageDialog(null, "N�o foi realizada vendas!!");
					} else {

						loja.exibirCupom(info);
					}

					break;

				case 6:
					loja.valorTotalCupons(info);

					break;

				}
			}

		} while (opcao != 7);

	}

}
