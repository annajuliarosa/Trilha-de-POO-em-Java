package Modelo;

import java.sql.Date;
import java.util.Calendar;

public class Cupom {
	
	private Calendar dataVenda = Calendar.getInstance();
	private double total;
	private int quantidade;
	private String descricao;

	
	public Calendar getdataVenda() {
		return dataVenda;
	}
	
	public void setdataVenda(Calendar dataVenda) {
		this.dataVenda=dataVenda;
	}
	
	public Double getTotal() {
		return total;
	}
	
	public void setTotal(double total) {
		this.total=total;
	}
	
	
	public int getQuantidade() {
		return quantidade;
	}
	
	public void setQuantidade(int quantidade) {
		this.quantidade=quantidade;
	}
	
	public String getDescricao() {
		return descricao;
	}
	
	public void setDescricao(String descricao) {
		this.descricao=descricao;
	}
	
	
	
}
