package Visualiza��o;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;

public class EntradaSaida {
	
	public static int solicitaOpcao(){
		
		String[] opcoes = { "Cadastrar Produtos", "Exibir Produtos", "Entrada em Estoque", "Vender Produto",
				"Exibir Produtos em estoque", "Exibir Cupons", "Exibir total de vendas", "Sair" };
		JComboBox<String> menu = new JComboBox<String>(opcoes);
		JOptionPane.showConfirmDialog(null, menu, "Selecione a op��o desejada", JOptionPane.OK_CANCEL_OPTION);

		return menu.getSelectedIndex();
		
	}
	
	
	public static String solicitaDescricao() {
		
		String descricao = JOptionPane.showInputDialog("Informe a descricao do produto: ");
		
		return descricao;
		
	}
	
	public static double solicitaPreco() {
		
		double preco= Double.parseDouble(JOptionPane.showInputDialog("Informe o valor do produto: "));
		
		return preco;
		
		
	}
	
	public static void exibirProdutos(String info) {
		
		JOptionPane.showMessageDialog(null, info);
		
	}
	
	public static int qtdEstoque() {
		
		int qtd=0;
		
		qtd= Integer.parseInt(JOptionPane.showInputDialog("Informe a quantidade do produto que gostaria de inserir: "));
		
		return qtd;
		
	}
	
	
	
	
	
	

		
		


}
