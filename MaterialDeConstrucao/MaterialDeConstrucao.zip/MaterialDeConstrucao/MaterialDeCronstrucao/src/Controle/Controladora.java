package Controle;

import javax.swing.JOptionPane;

import Modelo.Loja;
import Modelo.Produtos;
import Visualiza��o.EntradaSaida;

public class Controladora {
	
	Loja loja = null;
	
	Produtos produtos = null;
	
	
	public void exibirMenu() {
		int opcao=0;
		
		this.loja= new Loja();
		
		int codigo=0;
		do {		
			
			
			opcao=EntradaSaida.solicitaOpcao();
			
			if (opcao==0) {
				codigo++;
			}
			
			switch (opcao) {
						
			case 0:
				
				this.produtos= new Produtos();
					
				
				
								
				produtos.setCodigoProduto(codigo);		
				produtos.setDescricao(EntradaSaida.solicitaDescricao());
				produtos.setPreco(EntradaSaida.solicitaPreco());
				
								
				loja.cadastrarProdutos(produtos);
				
			break;
			
			case 1:
				
				String info="";
				loja.exibirProdutos(info);
				
				
			break;
			
			case 2:
				int codigoProduto=0;
				for (Produtos produto : loja.getListaDeProdutos()) {
				codigoProduto=Integer.parseInt(JOptionPane.showInputDialog("Informe o c�digo do produto: " + produto.getCodigoProduto() + produto.getDescricao()));
				}
				
				codigoProduto= produtos.getCodigoProduto();
				
				loja.setQuantidade(EntradaSaida.qtdEstoque());				
				loja.setCodigoProduto(codigoProduto);
				
				
				this.produtos= new Produtos();
				
				
				loja.entradaEstoque(produtos);
			
				
				
			break;
			
			case 3:
				loja.venderProdutos();
				
			break;
			
			case 4: 
			
			break;
			
			case 5:
				
			break;
			
			case 6:
				
				
			break;
			
			
			}
			
			
		}while(opcao!=7);
		
		
	}
	

}
