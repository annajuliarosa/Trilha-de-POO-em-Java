package Modelo;

import java.sql.Date;
import java.util.ArrayList;

import Visualiza��o.EntradaSaida;

public class Loja {
	
	private int quantidade;
	private int codigoProduto;
	private Date dataVenda;
	private double total;
	private ArrayList<Produtos>listaDeProdutos = new ArrayList<Produtos>();
	private ArrayList<Produtos>estoque = new ArrayList<Produtos>();
	
	
	public int getQuantidade() {
		return quantidade;
	}
	
	public void setQuantidade(int quantidade) {
		this.quantidade=quantidade;
	}
	
	public int getCodigoProduto() {
		return codigoProduto;
	}
	
	public void setCodigoProduto(int codigoProduto) {
		this.codigoProduto=codigoProduto;
	}	
	
	public Date getDataVenda() {
		return dataVenda;
	}
	
	public void setDataVenda(Date dataVenda) {
		this.dataVenda=dataVenda;
	}
	
	public double getTotal() {
		return total;
	}
	
	public void setTotal(double total) {
		this.total=total;
	}	
	
	
	public ArrayList<Produtos> getListaDeProdutos() {
		return listaDeProdutos;
	}
	
	public void setListaDeProdutos(ArrayList<Produtos> listaDeProdutos) {
		this.listaDeProdutos=listaDeProdutos;
	}
	
	
	public void cadastrarProdutos(Produtos produtos) {
		
		listaDeProdutos.add(produtos);	
		
	}
	

	
	public void exibirProdutos(String info) {				
		
		for (Produtos produto : getListaDeProdutos()) {
			info+= "C�digo do Produto: "+ produto.getCodigoProduto() + "Descricao do produto: " + produto.getDescricao() + "Pre�o do produto: " + produto.getPreco(); 
						
		}
		
		EntradaSaida.exibirProdutos(info);
				
		
	}
	
	public void entradaEstoque(Produtos produtos) {
		
		estoque.add(produtos);	
		
		System.out.print(quantidade);
		System.out.print(codigoProduto);
		
	}

	public void venderProdutos() {
		// TODO Auto-generated method stub
		
	}
	
	
	

	
}
