package Modelo;

import java.util.ArrayList;

public class Produtos {
	
	private int codigoProduto;
	private String descricao;
	private double preco;
	
	
	
	public int getCodigoProduto() {
		return codigoProduto;
	}
	
	public void setCodigoProduto(int codigoProduto) {
		this.codigoProduto=codigoProduto;
	}
	
	public String getDescricao() {
		return descricao;
	}
	
	public void setDescricao(String descricao) {
		this.descricao=descricao;
	}
	
	public double getPreco() {
		return preco;
	}
	
	public void setPreco(double preco) {
		this.preco=preco;
	}

	
	
	
	
	
	

}
