package Controle;

import javax.swing.JOptionPane;

import Modelo.Cupom;
import Modelo.Loja;
import Modelo.Produtos;
import Visualiza��o.EntradaSaida;

public class Controladora {

	Loja loja = null;

	Produtos produtos = null;

	public void exibirMenu() {
		int opcao = 0;

		this.loja = new Loja();

		int codigo = 0;

		do {

			opcao = EntradaSaida.solicitaOpcao();

			String info = "";
			if (opcao == 0) {
				codigo++;
			}

			if (this.produtos == null && opcao > 0 && opcao < 7) {

				JOptionPane.showMessageDialog(null, "N�o h� produtos cadastrados");

			} else {
				
				

				

					switch (opcao) {

					case 0:

						this.produtos = new Produtos();

						produtos.setCodigoProduto(codigo);
						produtos.setDescricao(EntradaSaida.solicitaDescricao());
						produtos.setPreco(EntradaSaida.solicitaPreco());

						loja.cadastrarProdutos(produtos);

						break;

					case 1:

						loja.exibirProdutos(info);

						break;

					case 2:

						this.produtos = new Produtos();

						String valores = "";
						for (Produtos produto : loja.getListaDeProdutos()) {

							valores += "\nC�digo do produto: " + produto.getCodigoProduto() + "\nDescricao Produtos: "
									+ produto.getDescricao() + "\n";

						}
						int codigoProduto = 0;
						int quantidade = 0;

						codigoProduto = EntradaSaida.solicitaCodigoProduto(codigoProduto, valores);

						quantidade = EntradaSaida.qtdEstoque(quantidade);

						loja.entradaEstoque(codigoProduto, quantidade);

						break;

					case 3:
						
						int codigoProdutoComprar = 0;	
						String valoresComprar = "";
						
						
						//if (produtos.getQuantidade()!=0) {
							
							for (Produtos produto : loja.getListaDeProdutos()) {

								valoresComprar += "\nC�digo do produto: " + produto.getCodigoProduto()
										+ "\nDescricao Produtos: " + produto.getDescricao() + "\n";

							}

							codigoProdutoComprar = EntradaSaida.solicitaCodigoProdutoComprar(codigoProdutoComprar,
									valoresComprar);

							Cupom cupom = new Cupom();

							cupom.setQuantidade(EntradaSaida.qtdVenda());

							loja.venderProdutos(codigoProdutoComprar, cupom);
					/*	}else {
							JOptionPane.showMessageDialog(null, "N�o h� produtos cadastrados em estoque!");
						}

						
					*/			

						
						break;

					case 4:

						loja.exibirEstoque(info);

						break;

					case 5:

						loja.exibirCupom(info);

						break;

					case 6:
						loja.valorTotalCupons(info);

						break;

					}
				}
			

		} while (opcao != 7);

	}

}
