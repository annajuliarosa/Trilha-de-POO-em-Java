package Modelo;

import java.sql.Date;
import java.util.ArrayList;

import javax.swing.JComboBox;

import Visualiza��o.EntradaSaida;

public class Loja {
	
	private ArrayList<Produtos>listaDeProdutos = new ArrayList<Produtos>();
	private ArrayList<Cupom>listaDeCupom = new ArrayList<Cupom>();
		

	
	public ArrayList<Produtos> getListaDeProdutos() {
		return listaDeProdutos;
	}
	
	public void setListaDeProdutos(ArrayList<Produtos> listaDeProdutos) {
		this.listaDeCupom=listaDeCupom;
	}
	
	public ArrayList<Cupom> getListaDeCupom() {
		return listaDeCupom;
	}
	
	public void setListaDeCupom(ArrayList<Cupom> listaDeCupom) {
		this.listaDeCupom=listaDeCupom;
	}
	
	
		public void cadastrarProdutos(Produtos produtos) {
		
		listaDeProdutos.add(produtos);	
		
	}
	
	public void exibirProdutos(String info) {				
			
			for (Produtos produto : getListaDeProdutos()) {
				info+= "C�digo do Produto: "+ produto.getCodigoProduto() + "\nDescricao do produto: " + produto.getDescricao() + "\nPre�o do produto: " + produto.getPreco() + "\n "; 
							
			}
			
			EntradaSaida.exibirInformacoes(info);						
		}
	
	
	public void entradaEstoque(int codigoProduto, int quantidade) {
		
		for (Produtos produtos : getListaDeProdutos()) {
			if (produtos.getCodigoProduto()==codigoProduto) {
				produtos.setQuantidade(produtos.getQuantidade()+quantidade);
			}
		}			
		
	}

	public void exibirEstoque(String info) {		
	
		for (Produtos produtos : getListaDeProdutos()) {
			info+= "C�digo do Produto: " + produtos.getCodigoProduto() +  "\nQuantidade de Produtos: " + produtos.getQuantidade() + "\n "; ; 
						
		}
		
		EntradaSaida.exibirInformacoes(info);
		
	}
	
	public void venderProdutos(int codigoProdutoComprar, Cupom cupom) {
		
	double totalVenda=0;
		
		for (Produtos produtos : getListaDeProdutos()) {
			
			if (produtos.getCodigoProduto()==codigoProdutoComprar) {
				produtos.setQuantidade(produtos.getQuantidade()-cupom.getQuantidade());
				cupom.getdataVenda().getTime();
				cupom.setDescricao(produtos.getDescricao());
				totalVenda= cupom.getQuantidade()*produtos.getPreco();
				cupom.setTotal(totalVenda);			
				
				listaDeCupom.add(cupom);
				
				
								
			}
			
			
				
				
			}
		
	}

	public void exibirCupom(String info) {
		for (Cupom cupom : getListaDeCupom()) {
			info+= "Data da Venda: " + cupom.getdataVenda().getTime() +  "\nDescricao do Produtos: " + cupom.getDescricao() + "\nQuantidade vendida: " + cupom.getQuantidade() + 
					"\nValor total: " + cupom.getTotal() + "\n "; 
			
		}
		
		EntradaSaida.exibirInformacoes(info);
		
		
	}

	public void valorTotalCupons(String info) {
		
		double total=0;
			
		for (Cupom cupom : getListaDeCupom()) {
			
			info= "Total das vendas: " + cupom.getTotalVendasTotal(); 
		}
				
		EntradaSaida.exibirInformacoes(info);
				
				
		
		
	}

	
	
	

	
}
