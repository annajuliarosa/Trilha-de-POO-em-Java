import Controle.Controladora;

public class Principal {

	public static void main(String[] args) {

		Controladora controle = new Controladora();
		
		controle.exibirMenu();
		
		

	}

}
